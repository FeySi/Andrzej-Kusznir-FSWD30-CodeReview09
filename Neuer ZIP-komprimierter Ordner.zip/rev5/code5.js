var Persons = [
                        {
			name: 'John',
			surname: 'Doe',
			age: 25,
   			myPhoto: "face1.jpg",	
			likes: 1  
			},
			           {
			name: 'John',
			surname: 'Doe',
			age: 25,
   			myPhoto: "face2.jpg",	
			likes: 2  
			},
			           {
			name: 'John',
			surname: 'Doe',
			age: 25,
   			myPhoto: "face3.jpg",	
			likes: 3  
			},
			           {
			name: 'John',
			surname: 'Doe',
			age: 25,
   			myPhoto: "face4.jpg",	
			likes: 4  
			},
				];

				getElementbyId(morelikes)

		var i = 0